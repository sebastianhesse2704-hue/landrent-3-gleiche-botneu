# Land Rent – 3 Gleiche Bot (Android)

Dies ist ein Android-Prototyp, der ohne PC auf dem Handy installiert werden kann,
wenn das Projekt über GitHub Actions gebaut wird.

## Wichtig

Der erste Prototyp verwendet nur lokale Android-Bilderkennung. Er ist bewusst
konservativ und wird bei Unsicherheit nicht klicken. Das bedeutet: Nach der
Installation kann die Erkennung auf deinem konkreten Spiel-Layout noch angepasst
werden müssen.

## APK ohne PC bauen

1. Auf dem Handy GitHub öffnen und ein neues Repository anlegen.
2. Alle Dateien dieses Projekts hochladen.
3. Unter **Actions** den Workflow **Build Android APK** starten.
4. Nach dem Build unter **Artifacts** die Datei
   `landrent-3-gleiche-bot-debug` herunterladen.
5. APK auf dem Handy öffnen und die Installation erlauben.
6. App öffnen und die Bedienungshilfe aktivieren.
7. Land Rent öffnen und den Bot über die laufende Benachrichtigung starten.

## Berechtigungen

Die App nutzt die Android Accessibility Service API für:
- Bildschirm-Screenshot (`takeScreenshot`, Android 11+)
- simulierte Touch-Gesten (`dispatchGesture`)

Sie sendet den Spielbildschirm nicht an einen Server.
