# 3-Gleiche: Spielstrategie v2

Die Strategie ist symbol-unabhängig: Kiwi, Orange und spätere Früchte werden nicht als feste Sonderfälle benötigt.

## Zustandsmodell

- `tray`: bis zu 7 aktuell abgelegte Symbole
- `tiles`: alle erkannten Karten auf dem Spielfeld
- `clickable`: nur Karten, die nicht von einer darüberliegenden Karte verdeckt sind
- `signature`: visueller Fingerabdruck des Symbols; gleiche Bilder bekommen dieselbe Gruppe

## Zugpriorität

1. **Dritte Karte einer 2er-Gruppe in der Ablage** suchen. Das ist der wichtigste Zug, weil danach drei gleiche Karten verschwinden.
2. Wenn keine Ablagegruppe vervollständigt werden kann: **sichtbares Paar** bevorzugt vorbereiten.
3. Ein Symbol, das bereits einmal in der Ablage liegt, bevorzugen, wenn dadurch später eine Dreiergruppe entstehen kann.
4. Bei 5 oder mehr belegten Ablageplätzen keine riskanten Einzelkarten anklicken, wenn kein sinnvoller Abschluss sichtbar ist.
5. Nach jedem Tap komplett neuen Screenshot analysieren; niemals eine lange Klickliste vorab abarbeiten.

## Erkennung

Die Kacheln werden über Form/Position des Kartenrahmens gesucht. Der Fruchttyp wird über einen visuellen Fingerabdruck gruppiert. Dadurch sind neue Früchte grundsätzlich möglich.

## Überdeckung

Eine Karte gilt als nicht anklickbar, wenn ihr Mittelpunkt von einer höher liegenden Kartenfläche überdeckt wird. Ambivalente Situationen werden konservativ behandelt.

## Sicherheitsprinzip

Wenn die Erkennung unsicher ist, soll der Bot lieber stoppen als einen zufälligen Zug machen.
